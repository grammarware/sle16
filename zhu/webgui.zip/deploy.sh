#!/bin/bash
sudo npm install
sudo npm install forever -g
