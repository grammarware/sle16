{-# Language DeriveDataTypeable, TemplateHaskell #-}

module LanguageDef where

import Text.Parsec
import Text.Parsec.Token

import Data.Typeable
import Data.Data

import Data.Map as Map

import Language.Haskell.TH

import Debug.Trace

langDef = LanguageDef
  {
    commentStart = "{-"
   ,commentEnd = "-}"
   ,commentLine ="--"
   ,nestedComments = True
   ,identStart = upper :: Parsec String () Char
   ,identLetter = alphaNum <|> char '_'
   ,opStart = oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,opLetter = oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,reservedNames = ["Abstract", "Concrete", "Actions", "data", "Adaptive" ]
   ,reservedOpNames = [""]
   ,caseSensitive = True
  }


generatedParser = makeTokenParser langDef


-- apply lexeme to a parser to make the parser skip all the following white spaces
byLexeme     = lexeme generatedParser
byWhiteSpace = whiteSpace generatedParser

byStrLit  = stringLiteral generatedParser
--byCharLit = charLiteral generatedParser
byInteger = integer generatedParser
byInt     = integer generatedParser
byFloat   = float generatedParser

-- we treat quotes and doublequotes the same!
byCharLit :: Parsec String () String
byCharLit = byLexeme (do
  string "'"
  str <- manyTill anyChar (try (string "'"))
  return str)
  <?> "byCharLit"


data ASTDataTypes   = ASTDataTypes   String [ASTDataType]    deriving (Show, Eq, Read)  -- ASTDataTypes (top level datatype) [datatypes]
data ASTDataType    = ASTDataType    String [ASTDataTypeDef] deriving (Show, Eq, Read) -- DataType type definitions.  DataType "Arith" [...]
data ASTDataTypeDef = ASTDataTypeDef String [ASTDataTypeDef] deriving (Show, Eq, Read) -- TypeDef constructor [types]

data CAST      = CAST String      [CDataType] deriving (Show, Eq) -- CAST (top level datatype) [datatypes]
data CDataType = CDataType String [CTypeDef]  deriving (Show, Eq) -- CDataType type definitions. CDataType "Expr" [...]
data CTypeDef  = CTypeDef String  [EitherTNT] deriving (Show, Eq) -- CTypeDef constructor [types]

-- Left: string Terminal. Right: others
type EitherTNT = Either String String -- either it is a string terminal or datatypes. nonterminal is reserved when finishing parsing and used when building the env. It is deleted later.

--------datatype defs for Actions part---------------
-- here the TypeDecl stores the source type and view type to be used for entrance of the program
-- (the types of the first action group)
data Program   = Program TypeDecl [Group]     deriving (Show, Eq)
data Group     = Group TypeDecl [Rule]        deriving (Show, Eq)
data TypeDecl  = TypeDecl ViewType SourceType deriving (Show, Eq)
-- source type is simpler --- just a nonterminal

type SourceType = String
type ViewType   = ASTDataTypeDef
type ViewCon    = String

data Rule =  NormalRule LHS RHS
          |  AdaptRuleP String String String -- the adaptive rule specified by the user with pattern syntax: [p| sp ] [p| vp ] [f| func |]
          |  AdaptRuleG String String -- the adaptive rule specified by the user with a general syntax: [f| lambda-func-predicate :: s->v->Bool |] [f| func |]
  deriving (Show, Eq)

data LHS = LHS LHSPattern deriving (Show, Eq) -- the left hand side of a rule is just represented by a pattern (matching by patterns)

data LHSPattern = NormalP ViewCon [LHSPattern]   -- NormalP: normal pattern(I just do not know how to call it)
                | ASPattern String LHSPattern    -- ASPattern: @
                | UpdVar String
                | LitPat LitPat
                | WildcardP
                | InParen LHSPattern
  deriving (Show, Eq)
-- As for NormalP "ConsList" [p,ps], for simplicity, the pattern is limited to  Cons [Some (Complex1 pat) (var pat)] (simpleVar) . (the second lhsPattern must be a variable)

data LitPat = LitStrPattern String
            | LitIntegerPattern Integer
            | LitIntPattern Int
            | LitFloatPattern Double
            | LitBoolPattern Bool
  deriving (Show, Eq)


-- the right hand side of a rule is merely a production rule plus some updates somewhere.
data RHS = RHS ProdrulePlus deriving (Show, Eq)

data ProdrulePlus = ProdrulePlus ProdruleName [Either Unchanged Update] deriving (Show, Eq)
data Unchanged    = Nonterminal  SourceType | Terminal String           deriving (Show, Eq)
-- "SourceType" is not always a "SourceType". (in Unchanged "SourceType". )
data Update       = NUpdate      UVar SourceType
                  | DUpdate      SourceType ProdrulePlus                deriving (Show, Eq)  -- deep update. deep pattern match
-----------------------

type ProdRuleEigen = [Either String String] -- Left: a terminal symbol. Right : datatypes

type ProdruleName = String
type UVar         = String

type EigenNameEnv   = Map (ProdRuleEigen,ProdRuleType) ProdruleName  -- (["Expr", "+", "Term"],"Expr") ---> "A0"
type NameEigenEnv   = Map ProdruleName (ProdRuleEigen,ProdRuleType)  -- "A0"   ---> (["Expr", "+", "Term"],"Expr")
type TypeNameEnv    = Map ProdRuleType [ProdruleName]                -- "Expr"  ---> ["A0","A1","A2"]
type NullEnv        = Map String String                              -- "Expr"  ---> "ExprNull0"
type ConsSubtreeEnv = Map String [ASTDataTypeDef]                    --   Add ---> [Arith, Arith]
-- we want to keep layouts/comments in when performing adaptation if the source and source' have similar production rules.
-- eg Add Expr Term   is similar to   Sub Expr Term (the type of corresponding sub trees matches)
-- "Add" ---> ([["Sub","subExpr0","layouts1","subTerm2"],...]
type SimilarProdruleEnv = Map String [[String]]


type ProdRuleType  = String
type ParsecU = Parsec String ()


eatLParen   = byLexeme (char '(' )
eatRParen   = byLexeme (char ')' )
eatLBrack   = byLexeme (char '[' )
eatRBrack   = byLexeme (char ']' )
eatWildCard = byLexeme (char '_')
eatListCons = byLexeme (char ':')
eatEmbed    = byLexeme (string "+>")
eatLineEnd  = byLexeme (string ";")
eatAs       = byLexeme (char '@')
eatTo       = byLexeme (string "->")
eatComma    = byLexeme (char ',')
eatOr       = byLexeme (char '|')
eatSemi     = eatLineEnd
eatColon    = eatListCons <?> "want a colon (\":\")"

-- variable. starting with lower character
tVariable :: ParsecU String
tVariable = byLexeme (do
  fst <- lower
  s   <- many (alphaNum <|> char '_' )
  return $ (fst:s))

-- type constructor. starting with capital character
tConstructor :: ParsecU String
tConstructor = byLexeme (identifier generatedParser)


-- basic combinators for parsing type definitions
-- a parser for parsing a single type field is parameterised.
-- because, in Abstract part, the AST data type definition. a type with type variables is always in a paren, eg: C (Maybe Int) (Either .. ..)
-- However, in Actions part, the type definition for a group do not need this parenthesis, eg: Maybe TExp +> Exp ( not (Maybe TExp) )
-- we just want to reuse these basic combinators...
tupleType :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
-- tupleType singleType = try (tuple singleType) <|> triple singleType
tupleType singleType = try (tuple singleType)

generalType :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
generalType singleType = do
  (ASTDataTypeDef tcon _) <- simpleType
  ts <- many1 singleType
  if length ts == 0
   then error "should not be here. should be handled by other cases"
   else return $ ASTDataTypeDef tcon ts

simpleType :: ParsecU ASTDataTypeDef
simpleType = byLexeme (do
  t <- tConstructor
  return $ ASTDataTypeDef t [])

tuple :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
tuple singleType = do
  eatLParen
  t1 <- singleType
  ts <- many1 (eatComma >> singleType)
  eatRParen
  return $ ASTDataTypeDef "Tuple" (t1:ts)

maybeType :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
maybeType singleType = do
  byLexeme $ string "Maybe"
  t <- singleType
  return $ ASTDataTypeDef "Maybe" [t]

listType :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
listType singleType = do
  eatLBrack
  t <- singleType
  eatRBrack
  return $ ASTDataTypeDef "List" [t]

eitherType :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
eitherType singleType = do
  byLexeme $ string "Either"
  l <- singleType
  r <- singleType
  return $ ASTDataTypeDef "Either" [l,r]

withParen :: ParsecU ASTDataTypeDef -> ParsecU ASTDataTypeDef
withParen singleType = do
  eatLParen
  i <- singleType
  eatRParen
  return $ i

