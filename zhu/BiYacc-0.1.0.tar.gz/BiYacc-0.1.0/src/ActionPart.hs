{-# Language DeriveDataTypeable #-}

module ActionPart where

import LanguageDef
import BiYaccUtils

import Text.Parsec.Token hiding (symbol)
import Text.Parsec
import Text.Parsec.Prim
import Text.Parsec.Combinator
import Control.Monad

import Text.PrettyPrint as TPP

import Data.List (intersperse, map, (\\), sort, nub)
import Data.Char (toLower)
import Data.Maybe (catMaybes, fromJust)
import Data.Map.Strict as Map (Map, lookup, adjust, singleton, unions, union, empty, fromList, toList, insert)

import Debug.Trace


------- basic (primitive type) parser
-- string literal. will change char literal to string literal
strLit :: Parsec String () LitPat
strLit = byLexeme $ (byCharLit >>= \s -> return (LitStrPattern s)) <|> (byStrLit  >>= \s -> return (LitStrPattern s))

numbersLit :: Parsec String () LitPat
numbersLit = byLexeme (do
  choice [ try byInteger >>= \i -> return (LitIntegerPattern i)
         , try byInt     >>= \i -> return (LitIntPattern (fromInteger i))
         ,     byFloat   >>= \f -> return (LitFloatPattern f)
         ])

boolLit :: Parsec String () LitPat
boolLit = byLexeme $ try $ (string "True"  >> return (LitBoolPattern True)) <|> (string "False" >> return (LitBoolPattern False))

tTerminal = byCharLit
------------

---------------actions parser ----------------
program :: SourcePos -> ParsecU Program
program srcPos = do
  setPosition srcPos
  byLexeme (string "Actions" <?> "expecting keyword \"Actions\"")
  grps <- many1 group
  eof
  let (Group entranceTydec _) = grps !! 0
  return $ Program entranceTydec grps

group :: ParsecU Group
group = do
  t@(TypeDecl vt st) <- typeDecl
  rules_ <- many1 (try rule)
  return $ Group t rules_

typeDecl :: ParsecU TypeDecl
typeDecl = do
  vt <- viewType
  eatEmbed
  st <-tConstructor
  return $ TypeDecl vt st


-- parse a single type (type field, type constructor ...)
viewType :: Parsec String () ASTDataTypeDef
viewType = (simpleType <?> "expecting a constructor") <|> (maybeType viewType <?> "expecting Maybe type") <|>
             (listType viewType <?> "expecting List type") <|>
             try (tupleType viewType <?> "expecting tuple syntax") <|>
             try (withParen viewType) <|> try (generalType viewType)

rule :: ParsecU Rule
rule =
  (do
    byLexeme (try (string "Adaptive")) <?> "keyword \"Adaptive\""
    eatColon
    parseAdaptiveP <|> parseAdaptiveG) <|>
  (do
    lhs_ <- lhs
    eatEmbed
    rhs_ <- rhs
    eatLineEnd
    return (NormalRule lhs_ rhs_))

----adaptive rule------------
parseAdaptiveP :: ParsecU Rule
parseAdaptiveP = do
  sp <- try getPattern
  vp <- getPattern
  fn <- getFunction
  eatLineEnd
  return (AdaptRuleP sp vp fn)

parseAdaptiveG :: ParsecU Rule
parseAdaptiveG = do
  pred <- getFunction
  fn <- getFunction
  eatLineEnd
  return (AdaptRuleG pred fn)

getPattern :: ParsecU String
getPattern = do
  byLexeme (string "[p|")
  p <- manyTill anyChar (try (string "|]" <?> "expecting ending bracket (\"|]\") for a pattern"))
  byWhiteSpace
  return p

getFunction :: ParsecU String
getFunction = do
  byLexeme (string "[f|")
  f <- manyTill anyChar (try (string "|]" <?> "expecting ending bracket (\"|]\") for a function"))
  byWhiteSpace
  return f


-----lhs------------
lhs = liftM LHS lhsPattern

-- overlapped pattern: [var@(...)] and [var]
-- listPat can overlap any other patterns... shall first try it
lhsPattern :: ParsecU LHSPattern
lhsPattern = try listPat <|> primitiveTypes <|> constructorPat <|>
             varOrAsPat <|> try tupleSyntax <|> lhsWithParen <|> wildPat


-- if a pattern is ListCons, its left operant can be any patter EXCLUDING ListCons which is RIGHT associative.
lhsPatternWithoutListCons = try listPatWihoutCons <|> primitiveTypes <|> constructorPat <|>
   varOrAsPat <|> try tupleSyntax <|> lhsWithParen <|> wildPat

varOrAsPat :: ParsecU LHSPattern
varOrAsPat = do
  v <- tVariable
  c <- try eatAs <|> return 'n'
  case c of
    -- aspattern
    '@' -> do
      eatLParen
      pattern <- lhsPattern
      eatRParen
      -- ad hoc. insert ASPattern into a parentheses to easily distinguish from other patterns
      return (ASPattern v pattern)
    -- just a variable, match anything
    'n' -> return (UpdVar v)

-- Constructor var1 (Just var2) ...
constructorPat :: ParsecU LHSPattern
constructorPat = liftM2 NormalP tConstructor (many (constructorArgs <?> "want a constructor"))


wildPat :: ParsecU LHSPattern
wildPat = eatWildCard >> return WildcardP

lhsWithParen :: ParsecU LHSPattern
lhsWithParen = do
  eatLParen
  innerpatterns <- lhsPattern
  eatRParen
  return innerpatterns


constructorArgs :: ParsecU LHSPattern
constructorArgs = try listPat <|> primitiveTypes <|> varOrAsPat <|>
  (tConstructor >>= \con -> return (NormalP con []) <?> "expecting a constructor") <|>
  try tupleSyntax <|> lhsWithParen <|> wildPat
  <?> "error in parsing constructor arguments"

primitiveTypes :: ParsecU LHSPattern
primitiveTypes = liftM LitPat strLit <|> liftM LitPat numbersLit <|> liftM LitPat boolLit

--------
listPat = try singletonOrEmptyList <|> lhsConsList
listPatWihoutCons = try singletonOrEmptyList


singletonOrEmptyList :: ParsecU LHSPattern
singletonOrEmptyList = do
  eatLBrack
  n <- try eatRBrack <|> return 'n'
  case n of
    'n' -> do
      inner <- lhsPattern
      eatRBrack
      return $ NormalP "Singleton" [inner]
    ']' -> return (NormalP "EmptyList" [])

lhsConsList :: ParsecU LHSPattern
lhsConsList = do
  elem <- lhsPatternWithoutListCons
  eatListCons    -- :
  elems <- lhsPattern
  return $ NormalP "ConsList" [elem, elems]


tupleSyntax :: ParsecU LHSPattern
tupleSyntax = do
  eatLParen
  p1 <- lhsPattern
  ps <- many1 (eatComma >> lhsPattern)
  eatRParen
  return $ NormalP "Tuple" (p1:ps)
----------------------------------


------rhs---------------------------
rhs :: ParsecU RHS
rhs = liftM RHS prodrulePlus

prodrulePlus :: ParsecU ProdrulePlus
prodrulePlus = many1 update >>= \upd -> return $ ProdrulePlus "EMPTY" upd

update :: ParsecU (Either Unchanged Update)
update = try (do
  -- normal update 1
  eatLParen
  var <- tVariable
  eatEmbed
  sub <- tConstructor
  eatRParen
  -- here the primitive type is changed, to hold the layouts/comments fields
  -- eg. Int is changed to (Int, String) to contain layout. it is somehow not good...
  return $ Right $ NUpdate var sub) <|>

  try (liftM (Left . Terminal) tTerminal) <|> -- terminal
  -- deep pattern
  try (update_deepPat) <|>

  -- normal update 2: the updated part is expanded to a deep pattern
  -- but since you cannot update both the whole deep pattern part and also some of its inner parts
  -- so here we skip the whole deep pattern part and treat it as a normal update.
  try (do
  eatLParen
  var <- tVariable
  eatEmbed
  Right (DUpdate con _) <- update_deepPat
  eatRParen
  -- here the primitive type is changed. eg Int is changed to (Int, String) to contain layout. it is somehow not good...
  return $ Right $ NUpdate var con) <|>
  -- non update
  (liftM (Left . Nonterminal) tConstructor)

-- deep pattern
update_deepPat :: ParsecU (Either Unchanged Update)
update_deepPat = do
  eatLParen
  con <- tConstructor
  eatTo
  deep <- prodrulePlus -- if we go deep, the type of the deep expressions is the name (aka nonterminal) of their parent
  eatRParen
  return $ Right (DUpdate con deep)
  <?> "error in RHS, deep pattern. possibly missing ';' in previous right hand side"

-- change Int, Integer, Float, Double to String. change Name to BiYaccNameTy
progToBiYaccType :: Program -> Program
progToBiYaccType (Program t grps) = Program t (map to1 grps)
  where
    to1 :: Group -> Group
    to1 (Group tydecls rules) = Group tydecls (map to2 rules)
    to2 :: Rule -> Rule
    to2 (NormalRule lhs (RHS (ProdrulePlus name tnts))) = NormalRule lhs (RHS (ProdrulePlus name (map to3 tnts)))
    to2 a@(AdaptRuleP{}) = a
    to2 a@(AdaptRuleG{}) = a
    to3 :: Either Unchanged Update -> Either Unchanged Update
    to3 (Left (Nonterminal st)) = Left (Nonterminal (toBiYaccTy st))
    to3 (Left (Terminal s)) = Left (Terminal s)
    to3 (Right (NUpdate uv st)) = Right (NUpdate uv (toBiYaccTy st))
    to3 (Right (DUpdate st (ProdrulePlus name tnts ))) = Right (DUpdate st (ProdrulePlus name (map to3 tnts)))




---------------------------------------------------
-- Add the production rule name to the RHS of an action.
addProdRuleName :: EigenNameEnv -> Program -> Program
addProdRuleName env (Program t grps) = Program t (map upd1 grps)
  where
    upd1 :: Group -> Group
    upd1 (Group (TypeDecl vt st) rules) = Group (TypeDecl vt st) (map (upd2 st) rules)
    upd2 :: SourceType -> Rule -> Rule
    upd2 st (NormalRule lhs (RHS (ProdrulePlus _ tnts))) = NormalRule lhs (RHS (update2ProdrulePlus st env tnts))
    upd2 _ a@(AdaptRuleP{}) = a
    upd2 _ a@(AdaptRuleG{}) = a

update2ProdrulePlus :: SourceType -> EigenNameEnv -> [Either Unchanged Update] -> ProdrulePlus
update2ProdrulePlus st env eitherupds =
  let pat = getProdrulePat eitherupds
      maybeProdrulename = Map.lookup (pat,st) env
  in  case maybeProdrulename of
        Nothing -> error $ "(basically should not arrive here) cannot find pattern in concrete data type (no such production rule):" ++ "(" ++ show pat ++ ", " ++ show st ++ ")"
        Just prodrulename -> ProdrulePlus prodrulename (map mdDeepPat eitherupds)
  where mdDeepPat :: Either Unchanged Update -> Either Unchanged Update
        mdDeepPat (Right (DUpdate st (ProdrulePlus _ tnts))) = Right $ DUpdate st $ update2ProdrulePlus st env tnts
        mdDeepPat other                                      = other

getProdrulePat :: [Either Unchanged Update] -> ProdRuleEigen
getProdrulePat = map getUpdPat
  where getUpdPat :: Either Unchanged Update -> Either String String
        getUpdPat (Left (Nonterminal st)) = Right st
        getUpdPat (Left (Terminal t)) = Left t
        getUpdPat (Right upd) = case upd of
                                  NUpdate _ st -> Right st
                                  DUpdate st _ -> Right st
---------------------------------------------------------------




---------------------------------------------------------------
-- check whether the RHS of an action exists
isRhsExist :: EigenNameEnv -> Program -> Maybe String
isRhsExist env (Program t grps) = case catMaybes (concatMap chkUpd1 grps) of
  [] -> Nothing
  errMsgs -> error $ "warning: \n" ++ foldr1c (id) (\e es -> e `newlineS` es) errMsgs
  where
    chkUpd1 :: Group -> [Maybe String]
    chkUpd1 (Group (TypeDecl _ st) rules) = concatMap (chkUpd2 st) rules
    chkUpd2 :: SourceType -> Rule -> [Maybe String]
    chkUpd2 st (NormalRule lhs (RHS (ProdrulePlus _ tnts))) = chkUpd3 st env tnts
    chkUpd2 _ AdaptRuleP{} = [Nothing]
    chkUpd2 _ AdaptRuleG{} = [Nothing]
    chkUpd3 :: SourceType -> EigenNameEnv -> [Either Unchanged Update] -> [Maybe String]
    chkUpd3 st env eitherupds =
      let pat = getProdrulePat eitherupds
      in  case Map.lookup (pat,st) env of
            Nothing -> [Just $ "cannot find pattern in concrete data type (no such production rule):" ++ "(" ++ show pat ++ ", " ++ show st ++ ")"]
            Just _  -> concatMap chkDeepPat eitherupds
      where chkDeepPat :: Either Unchanged Update -> [Maybe String]
            chkDeepPat (Right (DUpdate st (ProdrulePlus _ tnts))) = chkUpd3 st env tnts
            chkDeepPat other                                      = [Nothing]

---------------- RHS exhaustiveness check ---------------
-- check whether a group of actions use all the production rules.
simpleExhaustCheck :: Program -> TypeNameEnv -> NameEigenEnv -> EigenNameEnv -> Maybe String
simpleExhaustCheck (Program _ grps) tenv nenv eenv =
  case catMaybes (map (checkGrp tenv nenv eenv) grps) of
    [] -> Nothing
    errMsgs -> Just $ "warning: (however, the program may still be correct)\n" ++ foldr1c (id) (\e es -> e `newlineS` es) errMsgs

-- Maybe (error message)
checkGrp :: TypeNameEnv -> NameEigenEnv -> EigenNameEnv -> Group -> Maybe String
checkGrp tenv nenv eenv (Group (TypeDecl (ASTDataTypeDef vtCon vtts) st) rules) =
  case Map.lookup st tenv of
    Nothing -> error $ "non-terminal " ++ st ++ " not found. maybe a wrong type is written?"
    Just conNames' ->
      let conNames  = sort conNames'
          namesWrt  = nubSortedList . sort . map (extPrdRName st eenv) $ rules
          lack      = map (\e -> "In group: " ++ produceVarType vtCon vtts ++ "+> " ++ st ++ "," `newlineS`
                           "the production rule not found: " ++ st ++ " -> " ++
                           (concatSpace . map (either (\s -> "'" ++ s ++ "'") id) . fst . fromJust . Map.lookup e) nenv)
                      (conNames \\ namesWrt)
      in  if null lack
            then Nothing
            else Just $ foldr1c (id) (\e es -> e `newlineS` es) lack

nubSortedList :: Eq a => [a] -> [a]
nubSortedList [] = []
nubSortedList [x] = [x]
nubSortedList (x:y:z) = if x == y then nubSortedList (y:z) else x: nubSortedList (y:z)

extPrdRName :: SourceType -> EigenNameEnv -> Rule -> String
extPrdRName st eenv (NormalRule _ (RHS (ProdrulePlus _ tnts))) =
  maybe (error "production rule not found") id (Map.lookup ((getProdrulePat tnts),st) eenv)
extPrdRName _ _ (AdaptRuleP{}) = ""
extPrdRName _ _ (AdaptRuleG{}) = ""

----------------------------------------------------------------


---------- automatically extract production rules from actions --------
extProdRules :: Program -> String
extProdRules (Program entTy grps) =
  toString . rearrEntrance entTy . Map.toList . rebuild (Map.empty) . nubSortedList . 
    sort . concat . map (concat. map Map.toList . extGrp) $ grps
  where
    toString :: [(String, [[String]])] -> String
    toString [] = ""
    toString ((nont,prds):xs) =
      let abc = map (foldr1c id (\e es -> e ++ " " ++ es)) prds
          hdSpaces = replicate (length nont + 2) ' ' -- just for pretty-printed results
      in  (nont ++ " -> " ++ foldr1c (\e -> e ++ " ;") (\e es -> e `newlineS` hdSpaces ++  "| " ++ es) abc) `newlineSS` toString xs

    rebuild :: Map String [[String]] -> [(String, [String])] -> Map String [[String]]
    rebuild acc [] = acc
    rebuild acc ((k,prds):xs) = rebuild (case Map.lookup k acc of Nothing -> Map.insert k [prds] acc; Just _  -> Map.adjust (\p -> prds:p) k acc) xs
    rearrEntrance :: TypeDecl -> [(String, [[String]])] -> [(String, [[String]])]
    rearrEntrance (TypeDecl _ entSt) l =
      case filter (\(ty, _) -> ty == entSt) l of
      [ent]   -> ent : filter (\(ty, _) -> ty /= entSt) l
      (_:_:_) -> error "panic . should not be here. please contact the developer."

extGrp :: Group -> [Map String [String]]
extGrp (Group (TypeDecl _ st) rules) = map (collectPrdRule st) rules
  where
    collectPrdRule :: SourceType -> Rule -> Map String [String]
    collectPrdRule st (NormalRule _ (RHS prdp)) = collectPrdp prdp st
    collectPrdRule _ _ = Map.empty

    collectPrdp :: ProdrulePlus -> SourceType -> Map String [String]
    collectPrdp (ProdrulePlus _ tnts) st = collectTNTs tnts [] Map.empty
      --foldr1c collectTNTs (\e es -> (collectTNTs e) ++ " " ++ es) tnts
      where
        collectTNTs :: [Either Unchanged Update] -> [String] -> Map String [String] -> Map String [String]
        collectTNTs []                             acc deep = Map.singleton st acc `union` deep -- safe to use union
        collectTNTs (Left  (Nonterminal nont):xs)  acc deep = collectTNTs xs (acc ++ [nont]) deep
        collectTNTs (Left  (Terminal     t  ):xs)  acc deep = collectTNTs xs (acc ++ ["'" ++ t ++ "'"]) deep
        collectTNTs (Right (NUpdate _ nont  ):xs)  acc deep = collectTNTs xs (acc ++ [nont]) deep
        collectTNTs (Right (DUpdate nont prdp):xs) acc deep = collectTNTs xs (acc ++ [nont]) (collectPrdp prdp nont)
---------------------------------------------------------



--
{-
The file provide functions for generating AST of "Actions" part in a BiYacc file.
Like what we do when dealing with the production rules in "Concrete" part, we first generate a temporary AST with holes.
The holes are then filled up with the help of environment.
But this time these two procedures are called mutually recursively.

-}

