{-# Language DeriveDataTypeable, TemplateHaskell, FlexibleContexts, OverloadedStrings #-}
module ConcretePart (prtConcDTs, buildEnv, buildEnvForExhstvChk, buildTmpCAST, toCAST, pConfigs, addTopLevelDataype, addNullConstructor, addConsName) where

import LanguageDef
import BiYaccUtils

import Text.Parsec as Parsec hiding (State, newline)
import Text.Parsec.Token

import Control.Monad.State.Lazy (MonadState, State, get, put, evalState, liftM, liftM2)

import Data.Map as Map (singleton, union, unions, insert, empty)
import Data.List (foldl1)
import Text.PrettyPrint

import Debug.Trace


--will change char literal to string literal
terminal :: Parsec String () String
terminal = byLexeme (byStrLit <|> byCharLit) <?> "want a terminal."

nonterminal = tConstructor <?> "want a nonterminal."


buildTmpCAST :: Parsec String () CAST
buildTmpCAST = pConfigs >> liftM2 CAST (return "") (many1 datatype)


datatype :: Parsec String () CDataType
datatype = do
  t <- tConstructor
  first <- firstline
  following <- many followingline
  eatSemi
  return $ CDataType t (first:following)
  where
    firstline = do
      eatTo
      eithers_ <- many1 ( (terminal >>= return . Left) <|> (nonterminal >>= return  . Right) )
      return $ CTypeDef "" eithers_
    followingline = try (do
      eatOr
      eithers_ <- many1 (try (terminal >>= return . Left ) <|> try (nonterminal >>= return . Right))
      return $ CTypeDef "" eithers_)


-- cut off the configuration part from the Concrete Syntax.
pConfigs :: Parsec String () String
pConfigs = do
  byWhiteSpace
  byLexeme (string "Concrete" <?> "expecting keyword Concrete")
  confs <- try (many pConfig)
  return $ "Concrete\n\n" ++ concat confs


-- parse the configurations. such as precedences %left, %right...
-- and comment declarations: commentLine, commentBlock
pConfig :: Parsec String () String
pConfig = byLexeme (do
  string "%"
  content <- manyTill p0 (try (string ";"))
  return $ "%" ++ concat content ++ ";\n"
  )
  where p0 = try (string "';'") <|> try (string "\";\"") <|> (liftM (:[]) anyChar)
  -- try is used to spit out the quote or doublequote ...


---------------
-- transform tempCAST to CAST
toCAST :: CAST -> CAST
toCAST tmpcast = addNullConstructor . addTopLevelDataype . changeBiYaccTy . addConsName $ tmpcast

addTopLevelDataype (CAST _ defs) = let (CDataType t _) = head defs in CAST t defs



removeTerminal :: CAST -> CAST
removeTerminal (CAST topt cdatatypes) = CAST topt (map remove1 cdatatypes)
  where remove1 :: CDataType -> CDataType
        remove1 (CDataType t ctypedefs) = CDataType t (map remove2 ctypedefs)
        remove2 :: CTypeDef -> CTypeDef
        remove2 (CTypeDef con tnts) = CTypeDef con (filter (either (const False) (const True)) tnts)

-- add the constructor name to CAST in a state monad. generate a unique constructor name for each CTypeDef
addConsName :: CAST -> CAST
addConsName (CAST topt cdatatypes) = CAST topt (map refine1 cdatatypes)
  where
    refine1 :: CDataType -> CDataType
    refine1 (CDataType prefix ctypedefs) = CDataType prefix (evalState (mapM refine2 ctypedefs) (genNameList prefix))
    refine2 :: MonadState [String] m => CTypeDef -> m CTypeDef
    refine2 (CTypeDef _ tnts) = do
      nameList <- get
      put $ tail nameList
      return $ CTypeDef (head nameList) tnts


changeBiYaccTy :: CAST -> CAST
changeBiYaccTy (CAST topt cdatatypes) = CAST topt (map refine1 cdatatypes)
  where
    refine1 (CDataType prefix ctypedefs) = CDataType prefix (map refine2 ctypedefs)
    refine2 (CTypeDef t tnts) = CTypeDef t (map (either (Left) (Right . toBiYaccTy)) tnts)


addNullConstructor :: CAST -> CAST
addNullConstructor (CAST topt cdatatypes) = CAST topt $ (map refine1 cdatatypes)
  where
    refine1 :: CDataType -> CDataType
    refine1 (CDataType prefix ctypedefs) =
      CDataType prefix (ctypedefs ++ [CTypeDef (prefix ++ "Null") [] ])

-- the parameter is tempCAST, which does not contain "NullConstructor", "LayoutField", and "addConsName"
buildEnv :: CAST -> (EigenNameEnv, NameEigenEnv, NullEnv, SimilarProdruleEnv, TypeNameEnv)
buildEnv tmpCAST =
  let (CAST topt cdatatypes) = changeBiYaccTy . addConsName $ tmpCAST
      envs                   = map buildNameEigenEnv cdatatypes
      nullenv                = buildNullEnv (addConsName tmpCAST)
      similarProdruleEnv     = unions $ map buildSimilarEnv cdatatypes
      tyNameEnv              = unions $ map buildTyNameEnv cdatatypes
  in  (unions $ map fst envs, unions $ map snd envs, nullenv, similarProdruleEnv, tyNameEnv)


-- the parameter is tempCAST, which does not contain "NullConstructor", "LayoutField", and "addConsName"
-- build some env using unmodified production rules
buildEnvForExhstvChk :: CAST -> (EigenNameEnv, NameEigenEnv, TypeNameEnv)
buildEnvForExhstvChk tmpCAST =
  let (CAST topt cdatatypes) = addConsName tmpCAST
      envs                   = map buildNameEigenEnv cdatatypes
      tyNameEnv              = unions $ map buildTyNameEnv cdatatypes
  in  (unions $ map fst envs, unions $ map snd envs, tyNameEnv)


buildNameEigenEnv :: CDataType -> (EigenNameEnv,NameEigenEnv)
buildNameEigenEnv (CDataType t ctypedefs) = let envs = (map (build2 t) ctypedefs)
                                 in (unions $ map fst envs, unions $ map snd envs)
  where build2 :: String -> CTypeDef -> (EigenNameEnv, NameEigenEnv)
        build2 t (CTypeDef key patterns) = (singleton (patterns,t) key , singleton key (patterns,t))

-- build the NullEnv. from datatype to its null constructor. eg: Expr ---> ExprNull; Term ----> TermNull
buildNullEnv :: CAST -> NullEnv
buildNullEnv (CAST _ cdatatypes) = unions $ (map addNull cdatatypes)
  where addNull :: CDataType -> NullEnv
        addNull (CDataType prefix ctypedefs) = singleton prefix (prefix ++ "Null")


buildSimilarEnv :: CDataType -> SimilarProdruleEnv
buildSimilarEnv all@(CDataType _ ctypedefs) = unions $ map (similar2 all) ctypedefs
  where
    similar2 :: CDataType -> CTypeDef -> SimilarProdruleEnv
    similar2 (CDataType _ ctypedefs) theTypeDef = similar3 theTypeDef ctypedefs
    similar3 :: CTypeDef -> [CTypeDef] -> SimilarProdruleEnv
    similar3 a b = similar3_ a b []
    similar3_ :: CTypeDef -> [CTypeDef] -> [[String]] -> SimilarProdruleEnv
    similar3_ (CTypeDef key _)           []                           [] = Map.empty
    similar3_ (CTypeDef key _)           []                           ss = singleton key (reverse ss) -- reverse or not does not mater
    similar3_ pa@(CTypeDef key thePats) ((CTypeDef key' pats'): defs) ss =
      if key /= key' -- similar production rules does not contain itself
        then  if isMatched thePats pats'
                then similar3_ pa defs ( (key' : mkWithFreshName pats') : ss)
                else similar3_ pa defs ss
        else  similar3_ pa defs ss
        -- mkWithFreshName [Right Expr, Left '+', Right Term] ---> [subExpr0, layouts1, subTerm2]
    mkWithFreshName :: [EitherTNT] -> [String]
    mkWithFreshName ps = mkWithFreshName_ ps [] (map show [0,1..])
    mkWithFreshName_      []       acc _       = reverse acc
    mkWithFreshName_ (Left _  :xs) acc nseries = mkWithFreshName_ xs (("layouts" ++  head nseries) : acc) (tail nseries)
    mkWithFreshName_ (Right t :xs) acc nseries =
      let subtree = if isPrimitiveWithLayout t
                      then "(undefined, layouts" ++ head nseries ++ ")"
                      else "sub" ++ t ++ head nseries
      in  mkWithFreshName_ xs (subtree : acc) (tail nseries)

    isMatched :: [EitherTNT] -> [EitherTNT] -> Bool
    isMatched [] [] = True
    isMatched (x:xs) (y:ys) = if isMatchedSingle x y then isMatched xs ys else False
    isMatched _ _   = False
    isMatchedSingle :: EitherTNT -> EitherTNT -> Bool
    isMatchedSingle (Left _) (Left _)   = True -- both are terminals
    isMatchedSingle (Right x) (Right y) = x == y || isPrimitiveWithLayout x && isPrimitiveWithLayout y -- x and y are strings. just compare them.
    isMatchedSingle _ _                 = False

buildTyNameEnv :: CDataType -> TypeNameEnv
buildTyNameEnv (CDataType tyName defs) = Map.singleton tyName . map (\(CTypeDef n _) -> n ) $ defs

getConName :: State [String] String
getConName = do n <- get; put $ tail n; return $ head n

genNameList :: String -> [String]
genNameList name = zipWith (\a b -> a ++ b) (repeat name) (map show [0,1..])

------------- parser ends -------

------------- generate Haskell datatypes-------
-- print concrete syntax data types
prtConcDTs :: CAST -> String
prtConcDTs (CAST topt defs) = render $ vcat2 (map prtSrcDatatype defs) `newlineD` (genDrvBiGULGenericCST (CAST topt defs))

prtSrcDatatype :: CDataType -> Doc
prtSrcDatatype (CDataType dName defs) =
  ((datadec_head <+> text dName <+> equals) <+>
  foldl1 (\xs x -> xs $$ nestn2 (text "|" <+> x) ) (map prtSrcTypeDef defs))
  $$ nest2 datadec_drv

prtSrcTypeDef :: CTypeDef -> Doc
prtSrcTypeDef (CTypeDef dcons fields) = hsep (text dcons : map f fields)
  -- represent terminals as strings, with surrounding comments and layouts
  where f = either (const (text "String")) (\t -> text $ if isPrimitive t then wrap t else t)
        wrap t = "(" ++ t ++ ", String" ++ ")"

datadec_head = "data"
datadec_drv  = "deriving Eq"


genDrvBiGULGenericCST :: CAST -> Doc
genDrvBiGULGenericCST (CAST _ defs) = vcat (map gen1 defs)
  where
    gen1 (CDataType dName defs) = gen2 dName
    gen2 name = "deriveBiGULGeneric ''" <> text name

