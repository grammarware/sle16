package slbook.xcoupled;

public interface Operator<T> { }
