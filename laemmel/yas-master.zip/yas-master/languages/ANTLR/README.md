ANTLR appears here mainly as a language for parser description.

http://www.antlr.org/
