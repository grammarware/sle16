The Extended Grammar Language of softlangbook
