The programming language Java

http://en.wikipedia.org/wiki/Java_%28programming_language%29

Prolog is used throughout softlangbook as for occasional illustrations.
