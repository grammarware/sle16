# MML: MetaModeling Language

MML supports metamodels with a graph-based semantics.
MML is inspired by EMF - evem though it is much simpler.

