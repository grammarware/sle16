# FRL: Family by Name Language

A language for the representation of families.
The "by name" part refers to an aspect of the metamodel.
That is, closest friends are represented by name rather than by referemce.

