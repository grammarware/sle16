# TDL: Term Difference Language

TDL supports the representation of differences between terms.

