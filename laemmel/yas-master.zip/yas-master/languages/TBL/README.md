The tree-based buddy language of softlangbook
