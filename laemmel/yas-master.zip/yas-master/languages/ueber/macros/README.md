There is no .ueber file here.
These macros are loaded explicitly by prelude/ueber.pro.
This is necessary to have them available while preprocessing.
