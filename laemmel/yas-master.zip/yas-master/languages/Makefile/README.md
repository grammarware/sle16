The language used by the make utility for build management

http://en.wikipedia.org/wiki/Makefile
