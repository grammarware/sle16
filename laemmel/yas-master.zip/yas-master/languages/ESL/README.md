# ESL: Extended Signature Language

ESL supports a notation for algebraic signatures much in the sense of many-sorted algebras and also in close similarity to Haskell's algebraic data types. ESL feature primitive types, tuples, lists, and maybies. ESL is an extension of BSL: Basic Signature Language.
