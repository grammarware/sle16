-- BEGIN ...
-- Domains in a simple interpreter
module Language.BTL.Domains where

-- END ...
-- Results of evaluation
type Value = Either Int Bool
