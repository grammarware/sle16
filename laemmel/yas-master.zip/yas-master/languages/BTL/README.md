# BTL: Basic TAPL Language

TAPL refers to Pierce's textbook "Types and Programming Languages".
BTL features trivial operations on natural numbers and Boolean values.

