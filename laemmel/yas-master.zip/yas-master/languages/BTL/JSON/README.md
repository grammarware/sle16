Validated using https://json-schema-validator.herokuapp.com/

