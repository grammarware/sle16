Validated with http://www.freeformatter.com/xml-validator-xsd.html
