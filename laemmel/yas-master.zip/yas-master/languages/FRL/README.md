# FRL: Family by Reference Language

A language for the representation of families.
The "by reference" part refers to an aspect of the metamodel.
That is, closest friends are represented by reference rather than by name.

