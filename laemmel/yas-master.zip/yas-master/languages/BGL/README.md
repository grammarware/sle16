The Basic Grammar Language of softlangbook
