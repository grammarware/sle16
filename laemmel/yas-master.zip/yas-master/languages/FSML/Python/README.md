CC BY
http://creativecommons.org/licenses/
2013-14, Nico Beck, https://github.com/nico1510/
Adaptations due to Ralf Laemmel

Python implementation of the Finite State Machine Language
==========================================================

prerequisites : 

antlr python runtime 

https://pypi.python.org/pypi/antlr4-python2-runtime/

easy_install antlr4-python2-runtime

jinja2 package 

http://jinja.pocoo.org/docs/intro/#installation

easy_install Jinja2

graphviz

http://graphviz.org/

pygraphviz package (https://pypi.python.org/pypi/pygraphviz)

easy_install may work or perhaps include/lib dirs need to be arranged.

run "make build" to build the project and "make run" to run it

See the Makefile for the rest.

