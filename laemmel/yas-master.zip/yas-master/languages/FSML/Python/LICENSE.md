CC BY
http://creativecommons.org/licenses/
2013-14, Nico Beck, https://github.com/nico1510/
Adaptations due to Ralf Laemmel, https://github.com/rlaemmel/

