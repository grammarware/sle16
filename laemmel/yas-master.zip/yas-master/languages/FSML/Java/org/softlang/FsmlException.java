package org.softlang;

public class FsmlException extends RuntimeException {
	private static final long serialVersionUID = -2533003245801322558L;
}
