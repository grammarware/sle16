package org.softlang.fluent;

import org.softlang.FsmlObservation;

public interface Fsml extends FsmlConstruction, FsmlObservation { }
