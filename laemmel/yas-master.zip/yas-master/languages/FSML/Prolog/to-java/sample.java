// Generated code
public enum foo {v1, v2, v3}
