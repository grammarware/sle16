// Generated code
public enum State {locked, unlocked, exception}
