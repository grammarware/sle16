// Generated code
public enum Input {ticket, pass, mute, release}
