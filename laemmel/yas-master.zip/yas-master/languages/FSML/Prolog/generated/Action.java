// Generated code
public enum Action {collect, alarm, eject}
