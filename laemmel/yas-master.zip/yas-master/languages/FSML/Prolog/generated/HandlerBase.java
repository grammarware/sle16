// Reusable code
public interface HandlerBase<A> {
    public void handle(A a);
}
