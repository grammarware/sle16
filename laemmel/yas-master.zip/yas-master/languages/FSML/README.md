The FSML language, i.e., the Finite State Machine Language, of softlangbook
