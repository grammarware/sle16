-- BEGIN ...
module Language.FSML.Domains where
import Language.FSML.Syntax
-- END ...
-- Input of FSM simulation
type Input = [Event]
-- Output of FSM simulation
type Output = [Action]
