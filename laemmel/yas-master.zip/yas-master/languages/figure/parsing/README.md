Illusration of parsing options

See the .ueber file.
