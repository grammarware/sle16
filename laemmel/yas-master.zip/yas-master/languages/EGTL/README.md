# EGTL: Extended Grammar Transformation Language

Transformations on (EGL-based) grammars are modeled.

