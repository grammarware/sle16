# MMDL: MetaModel Difference Language

MMDL supports the representation of differences between metamodels.

