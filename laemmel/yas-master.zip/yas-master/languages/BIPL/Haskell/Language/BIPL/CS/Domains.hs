-- BEGIN ...
-- Store transformer transformers 
module Language.BIPL.CS.Domains where

import Language.BIPL.DS.Domains
-- END ...
type StoreTT = StoreT -> StoreT
