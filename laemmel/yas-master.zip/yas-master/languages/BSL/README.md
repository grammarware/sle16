# BSL: Basic Signature Language

BSL supports a notation for algebraic signatures much in the sense of many-sorted algebras and also in close similarity to Haskell's algebraic data types. BSL is extremely basic. It does not even feature primitive types. An extension of BSL is provided by ESL: Extended Signature Language.
