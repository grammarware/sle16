# BSTL: Basic Signature Transformation Language

BSTL is a simple language for signature transformations.
In fact, BSTL features two interpretations.
The first interpretation indeed serves for signature transformation.
The second interpretation serves co-transformation of conformant terms.

