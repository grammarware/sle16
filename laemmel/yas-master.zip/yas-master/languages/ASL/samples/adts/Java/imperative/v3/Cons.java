// Doubly linked lists
public class Cons {
	public int head;
	public Cons tail;
	public Cons init;
}
