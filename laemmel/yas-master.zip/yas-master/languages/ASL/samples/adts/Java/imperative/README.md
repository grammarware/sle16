We study the "imperative" implementation of an ADT for lists.
There are three versions in subdirs v1, v2, v3.
v1 leverages a singly linked list in the most basic manner.
v2 uses an extra pointer to the last element and maintains the length.
v3 uses a doubly linked list.
