The logic programming language Prolog

http://en.wikipedia.org/wiki/Prolog

Prolog is used throughout softlangbook as an executable specification language.

The current directory holds a few introductory Prolog snippets which may be helpful in getting started with Prolog, when used as an executable specification language, indeed.
