The Extended Functional Programming Language of softlangbook
