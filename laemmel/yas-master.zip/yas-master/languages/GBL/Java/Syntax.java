package org.softlang.gbl;
public class Syntax {
    public static class World {
        public Person[] persons;
    }
    public static class Person {
        public String name;
        public Person buddy;
    }
}
