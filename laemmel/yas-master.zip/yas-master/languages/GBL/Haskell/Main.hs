import Language.GBL.Syntax
import Language.GBL.Sample

main = do
  print $ smallWorld
