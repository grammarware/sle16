The graph-based buddy language of softlangbook
