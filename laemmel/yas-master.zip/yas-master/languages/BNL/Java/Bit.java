public abstract class Bit { }
