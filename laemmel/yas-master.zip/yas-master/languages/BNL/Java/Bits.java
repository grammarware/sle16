public abstract class Bits { }
