public class Zero extends Bit { }
