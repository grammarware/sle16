public class Integer extends Rest { }
