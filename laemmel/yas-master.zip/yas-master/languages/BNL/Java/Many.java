public class Many extends Bits {
    public Bit bit;
    public Bits bits;
}
