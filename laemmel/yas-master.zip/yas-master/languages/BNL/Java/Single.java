public class Single extends Bits {
    public Bit bit;
}
