public class Number {
    public Bits bits;
    public Rest rest;
}
