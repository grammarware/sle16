public class One extends Bit { }
