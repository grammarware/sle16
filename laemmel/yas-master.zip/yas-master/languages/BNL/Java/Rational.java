public class Rational extends Rest {
    public Bits bits
}
