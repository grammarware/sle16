public enum Bit { Zero, One }
