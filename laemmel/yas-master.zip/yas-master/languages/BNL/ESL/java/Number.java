// BEGIN ...
import java.util.List;
// END ...
public class Number {
    public List<Bit> bits;
    public List<Bit> rest;
}
