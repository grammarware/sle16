data Number = Number Bits Bits
type Bits = [Bit]
data Bit = Zero | One
