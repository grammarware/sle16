# DDL: Data Definition Language

DDL is essentially a SQL subset for data definition.
DDL's concrete syntax features CREATE TABLE statements.

