# BGPTL: Basic Grammar Parse Tree Language

The language of parse trees as resulting from BGL-based parsing

